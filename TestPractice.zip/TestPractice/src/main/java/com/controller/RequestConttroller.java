package com.controller;

import java.io.File;
import java.io.IOException;
import java.net.HttpCookie;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.dao.DaoClass;
import com.dao.DaoInterface;
import com.google.gson.Gson;
import com.pojo.Hospital;
import com.pojo.Register;
import com.service.CoronaUpdate;
import com.service.RegionData;
import java.io.File;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

@Controller
public class RequestConttroller {

	@Autowired
	DaoInterface dao;

	@RequestMapping("/home")
	public String home() {
		return "redirect:/";
	}
	
	@RequestMapping(path="adminpanel")
	public String admin(HttpServletRequest request)
	{
		
		Enumeration<String> en = request.getSession().getAttributeNames();

		int i = 0;
		while (en.hasMoreElements()) {
			if (en.nextElement().equals("Role")) {
				i = 1;
			} else {
				continue;
			}
		}

		if (i == 1) {
			
			if(request.getSession().getAttribute("Role").equals("ADMIN"))
			{
				return"AdminPannel";
			}
			else
			{
				return "redirect:/adminLogin";
			}
		
		}else
		{
			return "redirect:/adminLogin";
		}
		
	}

	/*
	 * @RequestMapping("/about") public String aboutPage() { return "AboutUs"; }
	 * 
	 * @RequestMapping("/contact") public String contactPage() { return "ContactUs";
	 * }
	 */
	@RequestMapping(path = "/userRegister", method = RequestMethod.GET)
	public String registerPage(Model m) {
		m.addAttribute("who", "user");
		return "Register";
	}

	@RequestMapping(path = "/addAdmin", method = RequestMethod.GET)
	public String addAdminPage(Model m) {
		m.addAttribute("who", "admin");
		return "Register";
	}

	@RequestMapping(path = "/userLogin", method = RequestMethod.GET)
	public String userLoginPage(Model m) {
		m.addAttribute("who", "user");

		return "Login";
	}

	@RequestMapping(path = "/adminLogin", method = RequestMethod.GET)
	public String adminLoginPage(Model m) {
		m.addAttribute("who", "admin");

		return "Login";
	}

	@RequestMapping(path = "/register", method = RequestMethod.POST)
	public String register(@RequestParam("file") CommonsMultipartFile ffile, Model m, HttpServletRequest request)
			throws IOException {
		System.out.println(ffile.getName());
		System.out.println("in register");
		Register register = new Register();
		register.setFirstName(request.getParameter("firstname"));
		register.setSecondName(request.getParameter("secondname"));
		register.setEmail(request.getParameter("email"));
		register.setBirthDay(request.getParameter("birthday"));
		register.setGender(request.getParameter("gender"));
		register.setMobileNo(request.getParameter("mobile"));
		register.setUserName(request.getParameter("username"));
		register.setPassword(request.getParameter("password"));
		register.setUserType("USER");
		register.setImage(ffile.getBytes());
		System.out.println(register);
		int a = this.dao.save(register);

		// m.addAttribute("who","user");
		return "redirect:/userLogin";
	}

	@RequestMapping(path = "/adminRegister", method = RequestMethod.POST)
	public String adminRegister(Model m, HttpServletRequest request) {
		Register register = new Register();
		register.setFirstName(request.getParameter("firstname"));
		register.setSecondName(request.getParameter("secondname"));
		register.setEmail(request.getParameter("email"));
		register.setBirthDay(request.getParameter("birthday"));
		register.setGender(request.getParameter("gender"));
		register.setMobileNo(request.getParameter("mobile"));
		register.setUserName(request.getParameter("username"));
		register.setPassword(request.getParameter("password"));
		register.setUserType("ADMIN");
		System.out.println(register);
		int a = this.dao.save(register);

		return "AdminPannel";
	}

	@RequestMapping(path = "/userlogin", method = RequestMethod.POST)
	public String userLogin(Model m, HttpServletRequest request, HttpServletResponse response) {

		Register register = new Register();

		int reg = dao.findByuserNamePass(request.getParameter("username"), request.getParameter("password"), "USER");

		if (reg == 0) {
			m.addAttribute("Type", "Error");
			m.addAttribute("who", "user");

			return "Login";
		}

		HttpSession session = request.getSession();
		session.setAttribute("userName", request.getParameter("username"));
		session.setAttribute("password", request.getParameter("password"));
		session.setAttribute("Role", "USER");

		Cookie loginDetails = new Cookie("Credentials",
				request.getParameter("username") + ":" + request.getParameter("password") + "USER");

		response.addCookie(loginDetails);
		loginDetails.setMaxAge(20000);
		// response.setHeader("loginDetails",request.getParameter("username")+":"+request.getParameter("password")+":"+"USER");

		m.addAttribute("session", session);

		return "redirect:/";
	}

	@RequestMapping(path = "/adminlogin", method = RequestMethod.POST)
	public String adminLogin(Model m, HttpServletRequest request, HttpServletResponse response) {

		Register register = new Register();

		int reg = dao.findByuserNamePass(request.getParameter("username"), request.getParameter("password"), "ADMIN");

		if (reg == 0) {
			m.addAttribute("Type", "Error");
			m.addAttribute("who", "admin");
			return "Login";
		}

		HttpSession session = request.getSession();
		session.setAttribute("userName", request.getParameter("username"));
		session.setAttribute("password", request.getParameter("password"));
		session.setAttribute("Role", "ADMIN");

		Cookie loginDetails = new Cookie("Credentials",
				request.getParameter("username") + ":" + request.getParameter("password") + ":" + "ADMIN");

		response.addCookie(loginDetails);
		loginDetails.setMaxAge(20000);
		m.addAttribute("session", session);

		return "AdminPannel";
	}

	@RequestMapping(path = "/logout", method = RequestMethod.GET)
	public String logout(Model m, HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.invalidate();
		return "redirect:/userLogin";
	}

	@RequestMapping(path = "/userDetails", method = RequestMethod.GET)
	public String userDetails(Model m, HttpServletRequest request) {

		Enumeration<String> en = request.getSession().getAttributeNames();

		int i = 0;
		while (en.hasMoreElements()) {
			if (en.nextElement().equals("Role")) {
				i = 1;
			} else {
				continue;
			}
		}

		if (i == 1) {
			
			if(request.getSession().getAttribute("Role").equals("ADMIN"))
			{
				
			
			ArrayList<Register> list = new ArrayList<Register>();
			list = (ArrayList) dao.getAll();

			m.addAttribute("listOfUsers", list);

			System.out.println(list);
			return "AdminPannel";
			}
			else
			{
				return "redirect:/adminLogin";
			}
		} else {
			return "redirect:/adminLogin";
		}
		
	
	}

	@ResponseBody
	@RequestMapping(path = "/getlist", method = RequestMethod.GET)
	public String getInfo() {
		ArrayList<Register> list = new ArrayList<Register>();
		list = (ArrayList) dao.getAll();
		String list1 = list.toString();
		return list1;
	}

	@RequestMapping(path = "/coronaupdate", method = RequestMethod.GET)
	public String coronaUpates(HttpServletRequest req, Model m) throws IOException, InterruptedException {
		System.out.println("before if");

		Enumeration<String> en = req.getSession().getAttributeNames();

		int i = 0;
		while (en.hasMoreElements()) {
			if (en.nextElement().equals("Role")) {
				i = 1;
			} else {
				continue;
			}
		}

		if (i == 1) {
			System.out.println("in corona");
			HttpRequest request = HttpRequest.newBuilder().uri(URI.create(
					"https://api.apify.com/v2/key-value-stores/toDWvRj1JpTXiM8FF/records/LATEST?disableRedirect=true"))
					.method("GET", HttpRequest.BodyPublishers.noBody()).build();
			HttpResponse<String> response = HttpClient.newHttpClient().send(request,
					HttpResponse.BodyHandlers.ofString());
			// System.out.println(response.body());
			Gson gson = new Gson();
			CoronaUpdate cupdate = gson.fromJson(response.body(), CoronaUpdate.class);

			List<RegionData> regions = Arrays.asList(cupdate.getRegionData());

			ArrayList<RegionData> reglist = new ArrayList<RegionData>(regions);
			// System.out.println(Arrays.asList(cupdate.getRegionData()));
			// System.out.println(cupdate);
			System.out.println(reglist);

			m.addAttribute("coronaInd", cupdate);
			m.addAttribute("regions", reglist);

			return "CoronaUpdates";

		} else {
			System.out.println("in else");
			return "redirect:/userLogin";
		}

	}

	@RequestMapping(path = "/getCompleteInfo/{data}", method = RequestMethod.GET)
	public String specificStateInfo(@PathVariable("data") String data, Model m, HttpServletRequest req)
			throws IOException, InterruptedException {

		Enumeration<String> en = req.getSession().getAttributeNames();

		int i = 0;
		while (en.hasMoreElements()) {
			if (en.nextElement().equals("Role")) {
				i = 1;
			} else {
				continue;
			}
		}

		if (i == 1) {

			HttpRequest request = HttpRequest.newBuilder().uri(URI.create(
					"https://api.apify.com/v2/key-value-stores/toDWvRj1JpTXiM8FF/records/LATEST?disableRedirect=true"))
					.method("GET", HttpRequest.BodyPublishers.noBody()).build();
			HttpResponse<String> response = HttpClient.newHttpClient().send(request,
					HttpResponse.BodyHandlers.ofString());
			// System.out.println(response.body());
			Gson gson = new Gson();
			CoronaUpdate cupdate = gson.fromJson(response.body(), CoronaUpdate.class);

			List<RegionData> regions = Arrays.asList(cupdate.getRegionData());

			System.out.println(data);

			ArrayList<RegionData> reglist = new ArrayList<RegionData>(regions);
			// System.out.println(Arrays.asList(cupdate.getRegionData()));
			// System.out.println(cupdate);

			RegionData region = new RegionData();
			for (RegionData reg : reglist) {

				if (reg.getRegion().equals(data)) {
					region = reg;
				}
			}

			System.out.println(reglist);

			m.addAttribute("region", region);

			return "CompleteInformation";
		} else {
			return "redirect:/userLogin";
		}
		
		
		
	}

	@RequestMapping(path="/hospitals/{name}")
	public String hospitals(@PathVariable("name") String name,Model m ,HttpServletRequest req)
	{
		Enumeration<String> en = req.getSession().getAttributeNames();

		int i = 0;
		while (en.hasMoreElements()) {
			if (en.nextElement().equals("Role")) {
				i = 1;
			} else {
				continue;
			}
		}

		if (i == 1) {

		ArrayList<Hospital> hos=dao.findHospital(name);
		System.out.println(hos);
		
		m.addAttribute("listOfHospitals",hos);
		return "HospitalList";
		}
		else
		{
			return "redirect:/userLogin";
		}
	}

	@RequestMapping(path="find")
	public String hos()
	{
		return "FindHospital";
	}
	
	@RequestMapping(path="/findhosp", method = RequestMethod.POST)
	public String findHosp(Model m,HttpServletRequest req)
	{
		
		String city =req.getParameter("search");
		
		ArrayList<Hospital> hos=dao.findHosp(city);
		
		m.addAttribute("listOfHospitals", hos);
		return"HospitalList";
	}
}
