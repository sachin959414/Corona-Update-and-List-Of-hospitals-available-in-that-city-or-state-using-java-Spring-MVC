package com.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.Transaction;
import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mysql.cj.x.protobuf.MysqlxDatatypes.Array;
import com.pojo.Hospital;
import com.pojo.Register;

@Repository
public class DaoClass implements DaoInterface {

	@Autowired
	HibernateTemplate hibernateTemplate;

	@Transactional
	public int save(Register r) {
		Integer i = (Integer) this.hibernateTemplate.save(r);

		return i;
	}

	@Override
	public List<Register> getAll() {
		List<Register> users = this.hibernateTemplate.loadAll(Register.class);

		return users;
	}

	@Override
	public String delete(Register t) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Register getUser(int a) {
		Register r = hibernateTemplate.get(Register.class, a);

		return r;
	}

	@Transactional
	@Override
	public int findByuserNamePass(String userName, String password, String type) {

		// List<Register> list= (List<Register>) hibernateTemplate.find("from Register
		// where userName = ? and password= ?", userName, password);
		Session session = hibernateTemplate.getSessionFactory().openSession();
		List<Register> list = session
				.createNativeQuery(
						"select * from Register where BINARY userName=? and  BINARY password=?  and BINARY userType=?")
				.setString(1, userName).setString(2, password).setString(3, type).getResultList();
		session.close();

		if (list.isEmpty()) {

			return 0;
		}
		return 1;
	}

	@Override
	public String findName(String userName, String Password, String type) {

		return null;
	}

	@Override
	public int userNameCheck(String username) {

		Query query = hibernateTemplate.getSessionFactory().openSession()
				.createNativeQuery("select * from register where  BINARY userName=?", Register.class);
		query.setString(1, username);
		List list = query.getResultList();
		if (list.isEmpty()) {
			return 1;
		}
		return 0;
	}

	@Override
	public ArrayList<Hospital> findHospital(String state) {

		Query<Hospital> q = hibernateTemplate.getSessionFactory().openSession()
				.createNativeQuery("select * from Hospital where state like ?", Hospital.class)
				.setString(1,"%"+state+"%");

		ArrayList<Hospital> hos = new ArrayList(q.list());

		
		
		return hos;
	}
	@Override
	public ArrayList<Hospital> findHosp(String city) {

		Query<Hospital> q = hibernateTemplate.getSessionFactory().openSession()
				.createNativeQuery("select * from Hospital where city like ?", Hospital.class)
				.setString(1,"%"+city+"%");

		ArrayList<Hospital> hos = new ArrayList(q.list());

		
		
		return hos;
	}


}
