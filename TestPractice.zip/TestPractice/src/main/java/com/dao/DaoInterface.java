package com.dao;
import java.util.ArrayList;
import java.util.List;

import com.pojo.Hospital;
import com.pojo.Register;

public interface DaoInterface {
	
	public int save(Register t);

	public List<Register>getAll();
	
	public String delete(Register t);
	
	public Register getUser(int a);
	
	public int findByuserNamePass(String userName,String Password,String type);
	
	public String findName(String userName,String Password,String type);
	
	public int userNameCheck(String username);
	
	public ArrayList<Hospital> findHospital(String state);

	public ArrayList<Hospital> findHosp(String city);


}
