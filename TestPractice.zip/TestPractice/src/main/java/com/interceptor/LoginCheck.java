package com.interceptor;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.dao.DaoInterface;

@Component
public class LoginCheck extends HandlerInterceptorAdapter {

	@Autowired
	DaoInterface dao;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
		System.out.println("in login check interceptor");
		
		Cookie cook[]=request.getCookies();
		
		for(int i=0;i<cook.length;i++)
		{
			System.out.println(cook[i].getName());
			if(cook[i].getName().equals("Credentials"))
			{
				System.out.println(cook[i].getName());
				String cred[]=cook[i].getValue().split(":");
				
				 int p=dao.findByuserNamePass(cred[0], cred[1],cred[2]);
				   
				 if(i==1)
				 {
					 return true;
			
				 }
				 break;
				 
				
			}
		}
		
		response.sendRedirect(request.getContextPath()+"/adminLogin");
		
		return false;
	}
}
