package com.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.dao.DaoInterface;

@Component
public class UserNameValidationInterceptor extends HandlerInterceptorAdapter
{
	@Autowired
	DaoInterface dao;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
		String userName=request.getParameter("username");
		
		int a=dao.userNameCheck(userName);
		System.out.println("you are in prehandler");
		if(a==0)
		{
			request.setAttribute("resend","true");
			request.setAttribute("who","user");
			request.getRequestDispatcher("Reregister.jsp").forward(request, response);
			//response.sendRedirect(request.getContextPath()+"/index.jsp");
			return false;
		}
		
		return true;
		
	}

	
}
