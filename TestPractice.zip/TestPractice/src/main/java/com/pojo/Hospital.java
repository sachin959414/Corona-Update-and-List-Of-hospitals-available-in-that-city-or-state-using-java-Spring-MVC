package com.pojo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Hospital {

	
	private String state;
	private String city;
	@Id
	private String hospitalId;
	private String hospitalName;
	private String Address;

	private String pinCode;
	private String phoneNo;
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	@Override
	public String toString() {
		return "Hospital [state=" + state + ", city=" + city + ", hospitalId=" + hospitalId + ", hospitalName="
				+ hospitalName + ", Address=" + Address + ", pinCode=" + pinCode + ", phoneNo=" + phoneNo + "]";
	}

	
	


}
