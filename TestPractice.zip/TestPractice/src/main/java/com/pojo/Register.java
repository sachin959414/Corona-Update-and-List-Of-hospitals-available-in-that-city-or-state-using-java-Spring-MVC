package com.pojo;

import java.util.Base64;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Transient;

@Entity
public class Register {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;
	
	private String firstName;
	private String secondName;
	private String email;
	private	String birthDay;
	private String gender;
	private String mobileNo;
	private String userName;
	private String password;
	private String userType;
	
	@Lob
	private byte[] image;
	
	@Transient
	private String base64Image;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSecondName() {
		return secondName;
	}
	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBirthDay() {
		return birthDay;
	}
	public void setBirthDay(String birthDay) {
		this.birthDay = birthDay;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	
	
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	
@Transient
	public String getBase64Image() {
		base64Image=Base64.getEncoder().encodeToString(this.image);
		return base64Image;
	}
	@Transient
	public void setBase64Image(String base64Image) {
		this.base64Image = base64Image;
	}
	@Override
	public String toString() {
		return "Register [userId=" + userId + ", firstName=" + firstName + ", secondName=" + secondName + ", email="
				+ email + ", birthDay=" + birthDay + ", gender=" + gender + ", mobileNo=" + mobileNo + ", userName="
				+ userName + ", password=" + password + "]";
	}
	 
	
	
}
