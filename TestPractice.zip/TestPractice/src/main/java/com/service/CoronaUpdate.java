package com.service;

import java.util.ArrayList;

import org.springframework.stereotype.Component;


@Component
public class CoronaUpdate
{
   
    private String recovered;

    private String recoveredNew;

    private String previousDayTests;

    private String activeCasesNew;

    private String readMe;

    private RegionData[] regionData;

    private ArrayList<RegionData> data;
    
    private String deaths;

    private String deathsNew;

    private String totalCases;

    private String activeCases;

    private String lastUpdatedAtApify;


    public String getRecovered ()
    {
        return recovered;
    }

    public void setRecovered (String recovered)
    {
        this.recovered = recovered;
    }

    public String getRecoveredNew ()
    {
        return recoveredNew;
    }

    public void setRecoveredNew (String recoveredNew)
    {
        this.recoveredNew = recoveredNew;
    }

    public String getPreviousDayTests ()
    {
        return previousDayTests;
    }

    public void setPreviousDayTests (String previousDayTests)
    {
        this.previousDayTests = previousDayTests;
    }

    public String getActiveCasesNew ()
    {
        return activeCasesNew;
    }

    public void setActiveCasesNew (String activeCasesNew)
    {
        this.activeCasesNew = activeCasesNew;
    }

    public String getReadMe ()
    {
        return readMe;
    }

    public void setReadMe (String readMe)
    {
        this.readMe = readMe;
    }

    public RegionData[] getRegionData ()
    {
        return regionData;
    }

    public void setRegionData (RegionData[] regionData)
    {
        this.regionData = regionData;
    }

    public String getDeaths ()
    {
        return deaths;
    }

    public void setDeaths (String deaths)
    {
        this.deaths = deaths;
    }

    public String getDeathsNew ()
    {
        return deathsNew;
    }

    public void setDeathsNew (String deathsNew)
    {
        this.deathsNew = deathsNew;
    }

    public String getTotalCases ()
    {
        return totalCases;
    }

    public void setTotalCases (String totalCases)
    {
        this.totalCases = totalCases;
    }

    public String getActiveCases ()
    {
        return activeCases;
    }

    public void setActiveCases (String activeCases)
    {
        this.activeCases = activeCases;
    }

    public String getLastUpdatedAtApify ()
    {
        return lastUpdatedAtApify;
    }

    public void setLastUpdatedAtApify (String lastUpdatedAtApify)
    {
        this.lastUpdatedAtApify = lastUpdatedAtApify;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ recovered = "+recovered+", recoveredNew = "+recoveredNew+", previousDayTests = "+previousDayTests+", activeCasesNew = "+activeCasesNew+", readMe = "+readMe+", regionData = "+regionData+", deaths = "+deaths+", deathsNew = "+deathsNew+", totalCases = "+totalCases+", activeCases = "+activeCases+", lastUpdatedAtApify = "+lastUpdatedAtApify+"]";
    }
}
