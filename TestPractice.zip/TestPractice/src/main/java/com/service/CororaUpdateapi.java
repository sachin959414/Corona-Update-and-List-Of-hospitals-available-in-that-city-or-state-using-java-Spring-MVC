package com.service;

import java.io.IOException;
import com.google.gson.*;

import java.net.URI;
import java.net.http.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
public class CororaUpdateapi {
	
	public static void main(String[] args) throws IOException, InterruptedException {
		
		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create("https://api.apify.com/v2/key-value-stores/toDWvRj1JpTXiM8FF/records/LATEST?disableRedirect=true"))
				.method("GET", HttpRequest.BodyPublishers.noBody())
				.build();
		HttpResponse<String> response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
		//System.out.println(response.body());
	      Gson gson = new Gson();
	 CoronaUpdate cupdate=   gson.fromJson(response.body(), CoronaUpdate.class);
	 
	 List<RegionData> regions= Arrays.asList(cupdate.getRegionData());
	 
		ArrayList<RegionData> reglist=new ArrayList<RegionData>(regions);
		// System.out.println(Arrays.asList(cupdate.getRegionData()));
		// System.out.println(cupdate);
		System.out.println(reglist);

		
		
		
		
	}

}
