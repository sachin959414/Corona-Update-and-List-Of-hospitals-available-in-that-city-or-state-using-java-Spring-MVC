package com.service;

import org.springframework.stereotype.Component;

@Component
public class RegionData
{
    private String totalInfected;

    private String recovered;

    private String deceased;

    private String newDeceased;

    private String newRecovered;

    private String newInfected;

    private String region;

    public String getTotalInfected ()
    {
        return totalInfected;
    }

    public void setTotalInfected (String totalInfected)
    {
        this.totalInfected = totalInfected;
    }

    public String getRecovered ()
    {
        return recovered;
    }

    public void setRecovered (String recovered)
    {
        this.recovered = recovered;
    }

    public String getDeceased ()
    {
        return deceased;
    }

    public void setDeceased (String deceased)
    {
        this.deceased = deceased;
    }

    public String getNewDeceased ()
    {
        return newDeceased;
    }

    public void setNewDeceased (String newDeceased)
    {
        this.newDeceased = newDeceased;
    }

    public String getNewRecovered ()
    {
        return newRecovered;
    }

    public void setNewRecovered (String newRecovered)
    {
        this.newRecovered = newRecovered;
    }

    public String getNewInfected ()
    {
        return newInfected;
    }

    public void setNewInfected (String newInfected)
    {
        this.newInfected = newInfected;
    }

    public String getRegion ()
    {
        return region;
    }

    public void setRegion (String region)
    {
        this.region = region;
    }

    @Override
    public String toString()
    {
        return "[totalInfected = "+totalInfected+", recovered = "+recovered+", deceased = "+deceased+", newDeceased = "+newDeceased+", newRecovered = "+newRecovered+", newInfected = "+newInfected+", region = "+region+"]";
    }
}
